package com.acire.githubuserapp

import android.os.Parcelable

@kotlinx.parcelize.Parcelize
data class User(
    var photo: Int = 0,
    var name: String? = "",
    var username: String? = "",
    var location: String? = "",
    var company: String? = "",
    var repository: String? = "",
    var followers: String? = "",
    var following: String? = ""
) : Parcelable